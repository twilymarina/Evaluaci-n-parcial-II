package com.example.ventasapi.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity // Indica que esta clase es una entidad JPA
@Table(name = "PRODUCT") // Especifica que está vinculada a la tabla PRODUCT
public class Product {

    @Id // Define este campo como clave primaria
    private String id; // Campo ID de la tabla

    private String nombre; // Campo Nombre de la tabla
    private Double precio; // Campo Precio de la tabla
    private Integer existencia; // Campo Existencia de la tabla
    private String descripcion; // Campo Descripcion de la tabla
    private String nombreProv; // Campo NombreProv de la tabla

    // Constructor vacío (necesario para JPA)
    public Product() {
    }

    // Constructor con parámetros (opcional)
    public Product(String id, String nombre, Double precio, Integer existencia, String descripcion, String nombreProv) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.existencia = existencia;
        this.descripcion = descripcion;
        this.nombreProv = nombreProv;
    }

    // Getters y Setters para cada campo
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Integer getExistencia() {
        return existencia;
    }

    public void setExistencia(Integer existencia) {
        this.existencia = existencia;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombreProv() {
        return nombreProv;
    }

    public void setNombreProv(String nombreProv) {
        this.nombreProv = nombreProv;
    }
}
