package com.example.ventasapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ventasapi.model.Product;

@Repository // Marca esta clase como un repositorio Spring
public interface ProductRepository extends JpaRepository<Product, String> {
    // Los métodos básicos CRUD (save, findAll, findById, deleteById) están disponibles automáticamente.
    
    // Puedes agregar métodos personalizados si lo necesitas, por ejemplo:
    // List<Product> findByNombre(String nombre);
}

